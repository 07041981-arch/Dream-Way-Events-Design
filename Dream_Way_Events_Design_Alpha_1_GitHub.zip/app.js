
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const KEY="dwe_alpha_01";
let data=JSON.parse(localStorage.getItem(KEY)||"null");
let currentQ=1;

function save(){localStorage.setItem(KEY,JSON.stringify(data));}
function toast(msg){const t=$("#toast");t.textContent=msg;t.classList.add("show");setTimeout(()=>t.classList.remove("show"),2400);}
function showScreen(id){$$(".screen").forEach(s=>s.classList.toggle("active",s.id===id));window.scrollTo(0,0);}
function showView(id){$$(".view").forEach(v=>v.classList.toggle("active",v.id===`view-${id}`));$$(".nav").forEach(n=>n.classList.toggle("active",n.dataset.view===id));hydrateBook();window.scrollTo(0,0);}
$$("[data-screen]").forEach(b=>b.onclick=()=>showScreen(b.dataset.screen));
$$("[data-view]").forEach(b=>b.onclick=()=>showView(b.dataset.view));
$("#meetingRequest").onclick=()=>toast("Solicitud registrada en la demo. La conexión con correo se activará al conectar Supabase.");

$("#demoAccess").onclick=()=>{
 data={p1:"María",p2:"Daniel",email:"demo@dreamwayevents.com",date:new Date(Date.now()+86400000*240).toISOString().slice(0,10),progress:8,act1:{}};
 save();hydrate();showScreen("app");showView("home");
};

$("#signupForm").onsubmit=e=>{
 e.preventDefault();
 data={p1:$("#p1").value.trim(),p2:$("#p2").value.trim(),email:$("#signupEmail").value.trim(),date:$("#weddingDate").value,progress:8,act1:{}};
 save();hydrate();showScreen("app");showView("home");toast("Producción creada correctamente.");
};
$("#loginForm").onsubmit=e=>{
 e.preventDefault();
 if(data && $("#loginEmail").value.trim().toLowerCase()===data.email.toLowerCase()){hydrate();showScreen("app");showView("home");}
 else toast("No existe una producción local con ese correo. Usa el modo demostración.");
};
$("#logoutBtn").onclick=()=>showScreen("landing");

function hydrate(){
 if(!data)return;
 const names=`${data.p1} y ${data.p2}`;
 $("#hello").textContent=`Bienvenidos, ${names}`;
 $("#storyTitle").textContent=`La historia de ${names}`;
 $("#avatar").textContent=(data.p1[0]+data.p2[0]).toUpperCase();
 $("#progressText").textContent=(data.progress||8)+"%";
 $("#progressBar").style.width=(data.progress||8)+"%";
 const d=Math.max(0,Math.ceil((new Date(data.date+"T12:00:00")-new Date())/86400000));
 $("#days").textContent=d;
 const a=data.act1||{};
 $("#q1").value=a.why||""; $("#q2").value=a.origin||""; $("#q5").value=a.vision||"";
 $$("#feelings button").forEach(b=>b.classList.toggle("selected",(a.feelings||[]).includes(b.textContent)));
 $$("#priorities button").forEach(b=>b.classList.toggle("selected",(a.priorities||[]).includes(b.textContent)));
 hydrateBook();
}
function collectAct(){
 if(!data)return;
 data.act1={
   why:$("#q1").value.trim(), origin:$("#q2").value.trim(), vision:$("#q5").value.trim(),
   feelings:$$("#feelings .selected").map(b=>b.textContent),
   priorities:$$("#priorities .selected").map(b=>b.textContent)
 };
 save();
}
$$(".choices button").forEach(b=>b.onclick=()=>{b.classList.toggle("selected");collectAct();});
$$("textarea").forEach(t=>t.oninput=()=>{
 $("#saveNote").textContent="Guardando...";
 clearTimeout(window.st);window.st=setTimeout(()=>{collectAct();$("#saveNote").textContent="Cambios guardados";},450);
});

const director=[
 "Queremos conocer el motivo que os ha traído hasta aquí.",
 "Las mejores producciones nacen de una historia verdadera.",
 "No buscamos una boda bonita. Buscamos una boda que haga sentir.",
 "Vuestras prioridades serán nuestra brújula.",
 "Esta frase será el punto de partida de la dirección creativa."
];
function renderQ(){
 $$(".question").forEach(q=>q.classList.toggle("active",Number(q.dataset.q)===currentQ));
 $("#questionIndex").textContent=`${currentQ} / 5`;
 $("#prevQ").disabled=currentQ===1;
 $("#nextQ").textContent=currentQ===5?"Finalizar el Acto I":"Siguiente escena";
 $("#directorCopy").textContent=director[currentQ-1];
}
$("#prevQ").onclick=()=>{if(currentQ>1){currentQ--;renderQ();}};
$("#nextQ").onclick=()=>{
 collectAct();
 if(currentQ<5){currentQ++;renderQ();return;}
 data.progress=22;save();hydrate();toast("Acto I completado. El Libro de Producción se ha actualizado.");setTimeout(()=>showView("book"),700);
};
function hydrateBook(){
 if(!data)return;
 const a=data.act1||{};
 $("#bookTitle").textContent=`La historia de ${data.p1} y ${data.p2}`;
 $("#bookCode").textContent=`DWE-${(data.p1.slice(0,2)+data.p2.slice(0,2)).toUpperCase()}-${new Date().getFullYear()}`;
 $("#bookWhy").textContent=a.why||"Todavía no habéis comenzado a escribir este capítulo.";
 $("#bookOrigin").textContent=a.origin||"Pendiente de completar.";
 $("#bookFeelings").textContent=(a.feelings||[]).join(" · ")||"Pendiente";
 $("#bookPriorities").textContent=(a.priorities||[]).join(" · ")||"Pendiente";
 $("#bookVision").textContent=a.vision?`“${a.vision}”`:"“La frase que definirá vuestra boda aparecerá aquí.”";
}
$("#printBook").onclick=()=>window.print();
renderQ();
if(data){hydrate();showScreen("app");showView("home");}

if('serviceWorker' in navigator){window.addEventListener('load',()=>navigator.serviceWorker.register('./sw.js').catch(()=>{}));}
