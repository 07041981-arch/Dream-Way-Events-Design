# Dream Way Events Design — Alpha 0.1

## Qué contiene
- Aplicación navegable y responsive.
- Registro local de una pareja.
- Acceso de demostración.
- Panel principal con cuenta atrás.
- Acto I: El Guion.
- Libro de Producción dinámico.
- Impresión o guardado del libro como PDF.
- Instalación como PWA.
- Datos persistentes en el navegador.

## Cómo probar
Abre `index.html` desde un servidor local o sube la carpeta completa a Netlify.

Para una prueba rápida:
1. Sube esta carpeta a Netlify usando “Deploy manually”.
2. Abre la URL que genere Netlify.
3. Pulsa “Acceso clientes”.
4. Pulsa “Entrar en modo demostración”.

## Importante
Esta Alpha funciona sin servidor y guarda los datos en el navegador. La autenticación todavía es local. La conexión real con Supabase requiere crear un proyecto y añadir:
- URL del proyecto
- Clave pública anon
- Tablas y políticas RLS

## Próximo Sprint
- Supabase Auth real.
- Base de datos multiusuario.
- Panel interno Dream Way Events.
- Subida de imágenes de inspiración.
- Solicitudes de reunión y mensajería.
